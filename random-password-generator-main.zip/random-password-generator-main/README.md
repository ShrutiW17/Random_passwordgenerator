# random-password-generator
An application to generate random passwords of different lengths with the choice of including different types of characters, also tells the strength of the password according to the pre-defined rules.
